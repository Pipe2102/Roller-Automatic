#include <Arduino.h>
#include <Servo.h>

Servo motorRoller;  // Servo de 360 grados

// Pines de los fotorresistores
int sensorLuzIzquierda = A0;
int sensorLuzCentro = A1;
int sensorLuzDerecha = A2;

// Rango de valores para la luz
int rangoLuzMax = 600;  // Máxima intensidad de luz
int rangoLuzMin = 400;   // Mínima intensidad de luz

// Estado inicial del roller
int estadoActual = 90;  // Posición inicial del roller (detenido)

// Rango de movimiento del motor
int anguloMin = 0;   // Ángulo mínimo del roller
int anguloMax = 180; // Ángulo máximo del roller

// Prototipos de las funciones
int determinarDireccionLuz(int luzIzquierda, int luzCentro, int luzDerecha);
void moverRoller(int angulo);

void setup() {
  // Inicializar comunicación serie
  Serial.begin(9600);

  // Configurar el pin del servo
  motorRoller.attach(7);  // Conecta el servo al pin 9

  // Inicializar el servo en posición detenida
  motorRoller.write(estadoActual);

  Serial.println("Sistema iniciado. Calibrando...");
}

void loop() {
  // Leer los valores de los fotorresistores
  int luzIzquierda = analogRead(sensorLuzIzquierda);
  int luzCentro = analogRead(sensorLuzCentro);
  int luzDerecha = analogRead(sensorLuzDerecha);

  // Imprimir los valores de los sensores
  Serial.print("Luz Izquierda: ");
  Serial.println(luzIzquierda);
  Serial.print("Luz Centro: ");
  Serial.println(luzCentro);
  Serial.print("Luz Derecha: ");
  Serial.println(luzDerecha);

  // Calcular el promedio de la luz para determinar la intensidad general
  int luzPromedio = (luzIzquierda + luzCentro + luzDerecha) / 3;
  Serial.print("Luz Promedio: ");
  Serial.println(luzPromedio);

  // Mapear el rango de luz promedio a 0-1000 (más claro a más oscuro)
  int luzNormalizada = map(luzPromedio, 0, 1023, 0, 1000);
  Serial.print("Luz Normalizada: ");
  Serial.println(luzNormalizada);

  // Ajustar el roller en función de la luz
  if (luzNormalizada < rangoLuzMin) {
    Serial.println("Luz insuficiente. Subiendo el roller...");
    moverRoller(60); // Subir el roller para permitir más luz
  } else if (luzNormalizada > rangoLuzMax) {
    Serial.println("Demasiada luz. Bajando el roller...");
    moverRoller(120); // Bajar el roller para bloquear luz
  } else {
    Serial.println("Luz dentro del rango deseado. Deteniendo el roller.");
    moverRoller(90); // Detener el roller
  }

  // Retraso para evitar movimientos bruscos
  delay(500);
}

// Función para determinar la dirección de la luz
int determinarDireccionLuz(int luzIzquierda, int luzCentro, int luzDerecha) {
  // Calcular el promedio de luz en cada lado
  int promedioIzquierda = (luzIzquierda + luzCentro) / 2;
  int promedioDerecha = (luzCentro + luzDerecha) / 2;

  // Comparar los promedios
  if (promedioDerecha > promedioIzquierda + 50) {
    return 1;  // Más luz a la derecha
  } else if (promedioIzquierda > promedioDerecha + 50) {
    return -1;  // Más luz a la izquierda
  } else {
    return 0;  // Luz balanceada
  }
}

// Función para mover el roller
void moverRoller(int angulo) {
  motorRoller.write(angulo);  // Mover el servo al ángulo deseado
  delay(500);  // Retraso para estabilizar el movimiento
}



